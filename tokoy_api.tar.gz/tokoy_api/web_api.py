# -*- coding: utf-8 -*-

from datetime import datetime
from flask import Flask, request


def create_app():
    app = Flask(__name__)
    api_prefix = '/test'

    @app.route(api_prefix, methods=['GET'])
    def general_alert():
        date_now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        #ip=request.headers['X-Real-Ip'] 
        if request.headers.getlist("X-Forwarded-For"):
            ip = request.headers.getlist("X-Forwarded-For")[0]
        else:
            ip = request.remote_addr
        return "hello, visitors: {}, date: {}.".format(ip, date_now)

    return app
